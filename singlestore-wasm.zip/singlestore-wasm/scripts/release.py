#!/usr/bin/env python3
"""Publish an explicit runtime distribution after isolated local checks; never connect to DB."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import venv
import zipfile
from common import SKILL


def package_files():
    names=[line.strip() for line in (SKILL/'distribution-files.txt').read_text().splitlines()
           if line.strip() and not line.startswith('#')]
    if len(names)!=len(set(names)): raise ValueError('duplicate distribution entry')
    paths=[]
    for name in names:
        p=SKILL/name
        if Path(name).is_absolute() or '..' in Path(name).parts or p.is_symlink() or not p.is_file():
            raise ValueError('missing or unsafe distribution entry: '+name)
        if not p.resolve().is_relative_to(SKILL.resolve()): raise ValueError('outside skill: '+name)
        if set(Path(name).parts)&{'tests','library','examples','artifacts','target','__pycache__'}:
            raise ValueError('development material in distribution: '+name)
        paths.append(p)
    return sorted(paths)


def audit(skill):
    for p in skill.rglob('*.md'):
        for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',p.read_text()):
            if '://' in link or link.startswith('#'): continue
            target=link.split('#')[0]
            if target and not (p.parent/target).is_file(): raise ValueError('broken document link: '+str(p)+': '+link)
    for p in (skill/'templates').rglob('*'):
        if p.is_file() and (re.search(r'"accepted"\s*:\s*true',p.read_text()) or p.name=='user-observations.json'):
            raise ValueError('historical decision in template: '+str(p))


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--dev-root',type=Path,help='External development directory containing tests and fixtures')
    ap.add_argument('--wheelhouse',type=Path,help='Optional offline wheels for an isolated Python venv')
    ap.add_argument('--workdir',type=Path,help='Keep extracted package and projects in a new directory')
    args=ap.parse_args();output=args.output.resolve();output.parent.mkdir(parents=True,exist_ok=True)
    evidence=output.parent/'verification'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    evidence.mkdir(parents=True)
    report={'status':'running','db_verification':'not_run','clickhouse_comparison':'not_run','projects':{},'checks':[],
            'environment':'Installed Rust toolchain; isolated extraction, not a fresh OS'}
    def save(): (evidence/'release-report.json').write_text(json.dumps(report,indent=2)+'\n')
    save()
    try:
        if args.workdir:
            work=args.workdir.resolve();work.mkdir(parents=True,exist_ok=False)
        else: work=Path(tempfile.mkdtemp(prefix='ssws-release-'))
        report['reproduction_directory']=str(work)
        files=package_files();snapshot={p.relative_to(SKILL).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
        candidate=work/'candidate.zip'
        with zipfile.ZipFile(candidate,'w',zipfile.ZIP_DEFLATED) as z:
            for p in files:z.write(p,'singlestore-wasm/'+p.relative_to(SKILL).as_posix())
        with zipfile.ZipFile(candidate) as z:z.extractall(work/'extracted')
        skill=work/'extracted/singlestore-wasm';scripts=skill/'scripts';audit(skill)
        python=Path(sys.executable)
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',SSWS_SKILL=str(skill));env.pop('PYTHONPATH',None);env.pop('SSWS_TEST_DB_CONFIG',None)
        def run(command,label):
            proc=subprocess.run(list(map(str,command)),cwd=work,env=env,capture_output=True,text=True)
            (evidence/(label+'.log')).write_text(proc.stdout+proc.stderr)
            if proc.returncode: raise RuntimeError(label+' failed; see '+str(evidence/(label+'.log')))
            report['checks'].append(label)
            return proc.stdout
        if args.wheelhouse:
            venv.create(work/'venv',with_pip=True);python=work/'venv/bin/python'
            run([python,'-m','pip','install','--no-index','--find-links',args.wheelhouse.resolve(),'-r',skill/'requirements.txt'],'dependencies')
        report['python_environment']='isolated venv' if args.wheelhouse else 'current interpreter'
        modules=[p.stem for p in scripts.glob('*.py')]
        run([python,'-c',f'import sys,importlib;sys.path.insert(0,{str(scripts)!r});[importlib.import_module(n) for n in {modules!r}]'],'runtime-imports')
        for shape in ('i64-unary','string-pair-i64','f64-scalar','json-array-udaf'):
            project=work/'scaffolds'/shape
            command=[python,scripts/'scaffold.py','--name','fresh_function','--shape',shape,'--output',project]
            if shape=='f64-scalar':command+=['--arguments','input_value','rate']
            run(command,shape+'-scaffold')
            m=json.loads((project/'function.json').read_text())
            if 'compatibility' in m or 'reference' in m or m['cases'] or (project/'artifacts').exists():raise ValueError('inherited task state')
            if shape=='json-array-udaf' and m['condition_array'] is not None:raise ValueError('inherited JSON policy')
        run(['rustc','--edition=2021','--test',skill/'templates/json-array-udaf/src/json_array.rs','-o',work/'parser-tests'],'parser-compile')
        run([work/'parser-tests'],'parser-tests')
        if args.dev_root:
            dev=args.dev_root.resolve()
            run([python,'-m','unittest','discover','-s',dev/'tests','-v'],'external-pipeline-tests')
            for name in ('handle_sum','numeric_affine','string_result','black_scholes_call'):
                project=work/'projects'/name;shutil.copytree(dev/'tests/fixtures'/name,project)
                run([python,scripts/'build.py',project],name+'-build')
                report['projects'][name]=json.loads(run([python,scripts/'status.py',project],name+'-status'))
                save()
            # Implement a fresh generic scaffold using an external test algorithm.
            project=work/'scaffolds/json-array-udaf'
            shutil.copy2(dev/'tests/fixtures/json_array_count/logic.rs',project/'src/logic.rs')
            m=json.loads((project/'function.json').read_text())
            m['condition_array']={'argument_index':0,'min_items':0,'max_items':100,'max_json_bytes':4096,
                                  'empty_result':'0','json_null':'preserve','sql_null':'not_null'}
            m['cases']=[{'id':'empty','rows':[],'expected':'0'},
                        {'id':'values','rows':[[{'json_array':[None,True,256]}],[{'json_array':[0,1]}]],'expected':'5'}]
            (project/'function.json').write_text(json.dumps(m,indent=2)+'\n')
            run([python,scripts/'build.py',project],'fresh-json-udaf-build')
            report['projects']['fresh_json_udaf']=json.loads(run([python,scripts/'status.py',project],'fresh-json-udaf-status'))
        else: report['development_tests']='not_run: no --dev-root supplied'
        current={p.relative_to(SKILL).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in package_files()}
        if current!=snapshot: raise ValueError('package sources changed during verification')
        report.update(status='passed',source_files=snapshot,package=str(output),file_count=len(files),
                      package_bytes=candidate.stat().st_size,package_sha256=hashlib.sha256(candidate.read_bytes()).hexdigest())
        staging=output.with_suffix('.zip.tmp');shutil.copy2(candidate,staging);staging.replace(output)
    except Exception as exc:
        report.update(status='failed',failure=str(exc));save();print(json.dumps(report,indent=2));raise SystemExit(1)
    save();print(json.dumps({'status':report['status'],'package':str(output),'report':str(evidence/'release-report.json'),
                            'file_count':report['file_count'],'bytes':report['package_bytes']},indent=2))


if __name__=='__main__':main()

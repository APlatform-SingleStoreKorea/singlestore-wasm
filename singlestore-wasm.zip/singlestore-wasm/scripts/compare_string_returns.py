#!/usr/bin/env python3
"""Authorized 9.1.1 TEXT/LONGTEXT comparison using identical Wasm and WIT.

Experimental LONGTEXT bypass is confined to this tool, never the normal generator.
Every object has a fresh name and only objects created here are removed.
"""
import argparse
import configparser
import hashlib
import json
from pathlib import Path
import secrets
import pymysql
from common import manifest, verify_build, identifier
from aggregate import registrations, cases
from db_verify import preflight_queries, existing_object_names
from return_contracts import resolve


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('project',type=Path);ap.add_argument('--config',required=True,type=Path)
    ap.add_argument('--output',required=True,type=Path);args=ap.parse_args()
    project=args.project.resolve();m=manifest(project);meta=verify_build(project)
    if m.get('kind')!='handle-udaf' or set(m['aggregates'])!={''}:
        ap.error('experiment requires one HANDLE aggregate variant')
    c=resolve(m,m['aggregates'][''])
    if c['abi']!='string' or c['sql_type']!='TEXT':ap.error('explicit string/TEXT fixture required')
    if args.config.stat().st_mode & 0o077:ap.error('credential file must have mode 600')
    cfg=configparser.ConfigParser(interpolation=None);cfg.read(args.config);client=cfg['client'];database=identifier(client['database'])
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    report={'status':'running','database':database,'wasm_sha256':meta['wasm_sha256'],'wit_sha256':meta['wit_sha256'],
            'variants':{},'classification':'unverified','cleanup_errors':[]}
    def save(): (out/'comparison.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,default=str)+'\n')
    def clean(exc):
        result=str(exc).replace((project/'artifacts/module.wasm.b64').read_text().strip(),'[WASM_BASE64]')
        for key in ('host','user','password'):
            if client.get(key):result=result.replace(client[key],'[REDACTED]')
        return result
    db=None;created=[];save()
    try:
        db=pymysql.connect(host=client['host'],port=client.getint('port',3306),user=client['user'],password=client.get('password',''),
                           database=database,charset='utf8mb4',autocommit=True,connect_timeout=10,read_timeout=120)
        with db.cursor() as cur:
            preflight={}
            for key,sql in preflight_queries(database):cur.execute(sql);preflight[key]=cur.fetchall()
            report['preflight']=preflight
            if preflight['version'][0][0]!='9.1.1':raise ValueError('experiment requires exact SingleStore 9.1.1')
            existing=existing_object_names(preflight)
            for sql_type in ('TEXT','LONGTEXT'):
                name='ssws_type_'+sql_type.lower()+'_'+secrets.token_hex(6)
                if name.lower() in existing:raise ValueError('object name collision')
                sql=registrations(project,m,database,name)[0]['sql']
                if sql_type=='LONGTEXT':sql=sql.replace('RETURNS TEXT CHARACTER SET','RETURNS LONGTEXT CHARACTER SET',1)
                path=out/(sql_type.lower()+'-register.sql');path.write_text(sql+';\n')
                row={'name':name,'registration':'not_run','show_create':'not_run','calls':'not_run','register_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
                report['variants'][sql_type]=row;save()
                try:
                    # This known incompatible registration is the experiment, not an expected input error.
                    cur.execute(path.read_text().removesuffix(';\n'));created.append(name);row['registration']='passed'
                except pymysql.MySQLError as exc:
                    row.update(registration='failed',error_code=exc.args[0],error=clean(exc));save();continue
                cur.execute(f'SHOW CREATE AGGREGATE `{database}`.`{name}`')
                row['show_create']=cur.fetchall();row['results']=[]
                for item in cases(m,database,name):
                    if 'expected_error' in item['case']:continue
                    try:
                        cur.execute(item['sql']);values=cur.fetchall()
                        ok=len(values)==1 and values[0][0]==item['case']['expected'] and values[0][2]==1
                        row['results'].append({'id':item['case']['id'],'values':values,'passed':ok})
                    except pymysql.MySQLError as exc:
                        row['results'].append({'id':item['case']['id'],'passed':False,'error':clean(exc)})
                row['calls']='passed' if row['results'] and all(x['passed'] for x in row['results']) else 'failed'
                # Observe NULL behavior without claiming a missing public NULL contract was verified.
                cur.execute(f'EXPLAIN SELECT `{database}`.`{name}`(CAST(NULL AS SIGNED))')
                row['null_input']={'status':'observed_only','contract':'NOT NULL argument; no nullable ABI is inferred'}
                try:
                    cur.execute(f'SELECT `{database}`.`{name}`(CAST(NULL AS SIGNED))')
                    row['null_input']['values']=cur.fetchall()
                except pymysql.MySQLError as exc:
                    row['null_input'].update(error_code=exc.args[0],error=clean(exc))
                save()
            t=report['variants']['TEXT'];l=report['variants']['LONGTEXT']
            if any(v['registration']=='passed' and v['calls']=='failed' for v in (t,l)):
                report['classification']='registration_passed_call_failed: investigate Wasm return area separately'
            elif t['registration']=='passed' and l['registration']=='failed':
                report['classification']='TEXT_passed_LONGTEXT_failed: inspect stored server diagnostic for callback type requirement'
            elif t['registration']=='failed' and l['registration']=='failed':
                report['classification']='both_failed: investigate WIT/ABI/function kind'
            elif t['registration']=='passed' and l['registration']=='passed':
                report['classification']='both_passed: investigate server patch and other contract differences'
            else:report['classification']='TEXT_failed_LONGTEXT_passed: policy evidence conflicts; investigate'
            report['status']='completed'
    except Exception as exc:report.update(status='failed',failure=clean(exc))
    finally:
        if db is not None:
            with db.cursor() as cur:
                for name in reversed(created):
                    try:cur.execute(f'DROP AGGREGATE `{database}`.`{name}`')
                    except Exception as exc:report['cleanup_errors'].append(clean(exc))
            db.close()
        save()
    print(json.dumps({'status':report['status'],'classification':report['classification'],'report':str(out/'comparison.json')},indent=2))
    if report['status']=='failed' or report['cleanup_errors']:raise SystemExit(1)


if __name__=='__main__':main()

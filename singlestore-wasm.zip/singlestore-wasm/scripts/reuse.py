#!/usr/bin/env python3
"""Materialize an exact, versioned implementation; never overwrite an existing project."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
from common import SKILL


def entry(name,version=None,root=SKILL):
    if not (root/'library/registry.json').is_file():
        raise ValueError('optional library unavailable; use scaffold.py or provide --library-root <directory containing library>')
    registry=json.loads((root/'library/registry.json').read_text())
    item=registry['functions'][name]
    version=version or item['default_version'];pin=item['versions'][version]
    folder=(root/'library'/pin['path']).resolve()
    if not folder.is_relative_to((root/'library').resolve()):raise ValueError('invalid registry path')
    actual={p.relative_to(folder).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    if actual!=pin['files']:raise ValueError('pinned implementation changed: '+name+'@'+version)
    return folder,{'name':name,'version':version,**pin}


def materialize(name,output,version=None,contract=None,root=SKILL,compatibility=None):
    folder,pin=entry(name,version,root)
    if contract is not None and json.loads(contract.read_text())!=json.loads((folder/'contract.json').read_text()):
        raise ValueError('contract differs; create a new implementation/version and revalidate')
    if output.exists():raise ValueError('output already exists; choose a new directory')
    manifest=json.loads((folder/'function.json').read_text())
    if compatibility is not None:
        from compatibility import require_ready
        arity=len(manifest['argument_types']) if manifest.get('kind')=='handle-udaf' else (len(manifest['arguments']) if manifest.get('shape')=='f64-scalar' else (2 if manifest['shape']=='string-pair-i64' else 1))
        require_ready(compatibility, arity, list(manifest['aggregates']) if manifest.get('kind')=='handle-udaf' else None)
    shutil.copytree(folder,output,ignore=shutil.ignore_patterns('artifacts','target','__pycache__','user-observations.json','verification.md','feasibility.md','provenance.json'))
    (output/'feasibility.md').write_text('# New request review required\n\nReview contract.json, source provenance, target compatibility and independent cases for this request.\nBuild, source comparison and DB verification have not run for this copy. Historical reports remain in the external library.\n')
    manifest.pop('compatibility',None)
    manifest['request_review_required'] = compatibility is None
    if compatibility is not None: manifest['compatibility']=compatibility
    (output/'function.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (output/'provenance.json').write_text(json.dumps(pin,indent=2)+'\n')
    return pin


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('name');ap.add_argument('--version')
    ap.add_argument('--library-root',type=Path,default=SKILL);ap.add_argument('--compatibility',type=Path);
    ap.add_argument('--output',type=Path,required=True);ap.add_argument('--contract',type=Path);args=ap.parse_args()
    pin=materialize(args.name,args.output,args.version,args.contract,args.library_root, json.loads(args.compatibility.read_text()) if args.compatibility else None)
    print(json.dumps({'name':pin['name'],'version':pin['version'],'output':str(args.output),'db_verification':'not_run_for_this_build'},indent=2))


if __name__=='__main__':main()

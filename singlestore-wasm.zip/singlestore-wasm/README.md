# SingleStore Wasm

함수 이름·설명 또는 Python/Rust 코드를 입력하면 적용 가능성 검토 → Rust 구현 → Wasm 컴파일 → Base64 변환 → 등록·검증 SQL 생성을 수행하는 Codex 스킬이다. 기본 대상은 SingleStore 9.1.1이다. Python은 원본 의미를 분석해 Rust로 이식하며 범용 자동 번역기는 포함하지 않는다.

## 설치와 사용

ZIP의 `singlestore-wasm` 폴더를 프로젝트 `.agents/skills/` 또는 개인 스킬 디렉터리에 설치한다. 기존 설치를 덮어쓰기 전에 보존한다. Python 3.12, Rust 1.85.0과 wasm32-unknown-unknown 타깃을 준비하고 `python -m pip install -r requirements.txt`를 실행한다. Python 원본 비교가 필요할 때만 `requirements-python.txt`를 설치한다. [환경 설정](references/workflow.md)을 따른다.

```text
$singlestore-wasm 두 문자열의 편집 거리를 Unicode 코드 포인트 기준으로 구현해줘.
$singlestore-wasm 이 Python 코드를 SingleStore Wasm으로 변환해줘.
```

함수 이름·설명·코드 분석 후 새 디렉터리에 구현한다. `scripts/scaffold.py`는 string-pair-i64, i64-unary, f64-scalar, json-array-udaf starter를 제공한다. 완성된 함수 라이브러리 없이 사용할 수 있다. 공통 `build.py`는 실제 테스트·컴파일·Base64 왕복·SQL을 생성하고 `status.py`는 현재 산출물의 상태를 확인한다. 미구현 scaffold는 빌드를 통과하지 않는다.

호출 방식·반환 형식·계산 의미 변경은 [호환성 결정](references/compatibility-decisions.md)을 따른다. JSON 배열의 조건 수·NULL·빈 입력은 함수별로 결정하며 [입력 계약](references/json-condition-array.md)을 참고한다. DB 접속과 작업이 허용된 경우에만 `db_verify.py`를 실행한다. 새 프로젝트는 빌드·원본 비교·DB 검증 미실행 상태로 시작한다.

[SKILL.md](SKILL.md)의 최종 출력 형식과 실행 환경 제약 표를 유지한다. Wasm·Base64·등록 SQL·정상 검증 SQL·오류 검증 SQL 링크, 실제 출처·버전·커밋·원본 비교 상태를 제공한다. 로컬 빌드 성공과 실제 DB 호환 성공은 구분한다.

## 배포 범위

`distribution-files.txt`가 기본 배포 파일의 명시적 목록이다. 공통 도구·ABI/타입/출처 지침·범용 템플릿·의존성과 에이전트 메타데이터를 포함한다. 완성 함수, 테스트/fixture, 작업별 검증 기록은 개발 저장소의 `development/`에 별도로 보관하며 ZIP에는 넣지 않는다.

선택적 재사용은 외부 library를 명시하고 새 요청 계약을 검토한다. 과거 승인이나 성공 기록을 새 프로젝트에 적용하지 않는다. [재사용·외부 개발 자료를 이용한 배포 검증](references/common-pipeline.md)을 참고한다.

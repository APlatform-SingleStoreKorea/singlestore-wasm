---
name: singlestore-wasm
description: Implement function names/descriptions or supplied Python/Rust code as SingleStore Wasm functions. Analyze Python semantics and port them to Rust. By default, assess feasibility for SingleStore 9.1.1, implement and compile real Wasm, and deliver Base64 and registration SQL. Use common scalar/aggregate tools and optional pinned implementations; report machine-checked build and authorized DB verification status.
---

# SingleStore Wasm 함수 생성

사용자 요구를 **SingleStore에 등록·실행 가능한 함수**로 구현한다. 입력은 ① 코드와 “이걸 SingleStore Wasm으로 변환해줘” 또는 ② 함수 이름·동작 설명과 구현 요청이다. Python 코드 분석·Rust 이식과 기존 Rust 입력을 지원한다. 다른 언어는 원본 의미와 이식 가능성을 별도로 판단하며 일괄 지원을 가정하지 않는다. 사용자가 ABI·Rust 타입·라이브러리 대체·검증 방식을 지정할 필요는 없다.

Python 입력에서는 [Python 이식 절차](references/python-porting.md)를 읽는다. Codex가 소스와 의존성을 분석해 Rust로 구현하는 흐름이며 별도의 범용 Python→Rust 자동 변환기는 만들지 않는다. 원본 실행이 가능하면 독립 기준으로 비교하고, 실행 불가 시 이유와 대체 검증 근거를 기록한다. 함수 이름·설명 입력은 기존 판단·구현 절차를 따른다.

## 기본 완료 범위

사용자가 구현할 함수만 간단히 요청해도 스킬이 선택되면 **① 적용 가능성 판단 → ② Rust와 연결 코드 구현·실제 Wasm 컴파일 → ③ 실제 바이너리의 Base64 변환·등록 SQL 제공**을 기본으로 수행한다. 사용자가 명시적으로 검토만 요청하는 등 범위를 제한한 경우에는 그 범위를 따른다.

기본 대상은 **SingleStore 9.1.1**이다. 다른 버전을 지정하면 해당 버전을 기준으로 판단한다. 구현 가능한 경로가 있으면 적합성 설명이나 계획만 제시하고 멈추지 말고 빌드와 산출물 생성까지 이어간다. DB 접속 정보가 없어도 로컬 구현·빌드·인코딩은 진행하고 DB 등록·호출은 미검증으로 표시한다. 컴파일 성공과 실제 DB 호환 성공은 구분한다.

먼저 요구사항과 호환성을 분석한다. 코드·SQL 또는 기존 대화에서 인자 개수가 명확하면 해당 범위로 자동 진행한다. 내부 구현만 달라지고 사용자 호출 방식·반환 형식·계산 의미가 유지되면 자동 진행한다. 원본 대비 공개 함수 개수·호출 방식·반환 형식·계산 의미를 바꿔야 하면 차이와 구체적인 선택지를 설명하고 답변을 받은 뒤 설계를 확정한다. 전체 지원 요청은 범위 선택이며 반환 형식·계산 의미 변경 동의가 아니다. 이미 합의한 사항은 다시 묻지 않는다.

모든 요청에서 [호환성 차이와 사용자 확인](references/compatibility-decisions.md)을 읽고 분석 → 범위·차이 결정 → 생성 → 등록 순서를 따른다. 답변 전에도 공통 조사·분석은 진행하지만 선택이 필요한 함수의 설계·생성·등록은 확정하지 않는다. 통상적인 내부 구현·출력 경로는 스킬이 정한다. 불가능하거나 차단된 경우에는 근거, 실패 단계, 필요한 정보 또는 환경을 설명한다. 수정 가능한 실패는 해결하고 재시도하되, 실패·부분·이전 산출물을 이번 요청의 정상 결과처럼 제공하지 않는다.

## 판단과 계약

1. 작업 디렉터리, 적용 AGENTS.md, 기존 파일과 도구를 확인한다. 새 출력 디렉터리를 사용하고 기존 구현을 덮어쓰지 않는다.
2. 함수 이름·설명 또는 코드를 분석해 새 프로젝트를 생성한다. 선택적 외부 library가 제공되면 고정 계약을 새 요청과 비교하여 재사용할 수 있지만 기본 생성에는 필요하지 않다. [공통 실행 절차](references/common-pipeline.md)의 재사용 경로도 현재 요청의 계약·출처 검토를 요구하며 과거 승인·검증 성공을 상속하지 않는다. [compatibility.md](references/compatibility.md)와 참조 함수의 공식 문서·필요한 원본 소스를 확인하고 함수별 `feasibility.md`를 만든다. 참조 버전, 동작·입출력·옵션·기본값·경계 사례와 출처를 기록하고 대상 SingleStore의 지원 범위에 대응시킨다. 입력/출력/NULL, 함수 형태(UDF/UDAF/TVF), Unicode·정밀도·순서 의미, ABI/WIT, 외부 의존성, 메모리·시간·모듈 한도를 기록한다.
3. 가능 / 조건부 가능 / 불가 및 근거를 구분한다. **현재 스킬의 템플릿 부재는 SingleStore의 구현 불가능을 뜻하지 않는다.** 필요한 연결 코드·템플릿·빌드/검증 도구의 확장 가능성을 검토하고, 구현 가능한 미구현 부분은 이어서 작성한다. ABI 구현 또는 DB 검증이 남았다는 이유만으로 로컬 작업을 중단하지 않는다. 문서만으로 미확인인 항목을 성공으로 적지 않는다. v9.1 문서는 서버의 정확한 패치 버전과 동일하다고 가정하지 않는다.
4. 함수 설명·원본 코드로부터 기대값을 먼저 정한다. 빌드 후 실제값에 맞춰 기대값을 변경하지 않는다. 코드 입력은 파일/네트워크/프로세스/스레드/FFI/난수·시간 등 외부 의존성과 라이브러리 호출부터 검토한다. 원본에 정의된 동작을 우선하며, 미정의 NULL은 기본적으로 전파하고 잘못된 입력·비유한 결과는 명시적 오류로 처리한다. 경계값은 원본의 관찰 가능한 계산 의미를 보존한다. 기본 정책·오류 매핑·지원 입력 범위를 최종 `입력 계약과 제한`에 표시한다. 원본에 정의된 반환·계산 의미를 바꾸는 오류 매핑, 수학적 확장·오류 수정·입력 축소는 크기에 관계없이 사용자 확인 대상이다. 합리적인 기본값이라는 이유로 변경 동의를 대신하지 않는다.

## 가변 조건 입력

동일한 의미의 반복 조건을 받는 가변 인자는 기본적으로 행별 `JSON_BUILD_ARRAY(...)` 하나로 묶는다. 조건 개수를 묻거나 개수별 공개 함수를 생성하지 않는다. 사용자가 고정 인자/기존 호출 유지를 명시하면 우선한다. Levenshtein의 두 문자열, Black–Scholes의 서로 다른 인자는 유지한다. sequenceMatch/sequenceCount는 패턴·시간을 유지하고 반복 조건 부분만 배열로 묶는다. 자세한 설정·템플릿·빈 입력 결정은 [JSON 조건 배열](references/json-condition-array.md)을 읽는다. 이 기본 호출 설계 자체를 다시 승인받지 않는다. 미합의 반환 의미 변경(특히 빈 입력)은 구체적 차이만 확인한다.

## 생성과 구현

이름·설명 기반 요청은 [원본 출처와 실행 비교](references/reference-verification.md)를 따른다. 공식 문서 및 원본 소스의 실제 참조 링크·버전·커밋과 확보 여부를 기록한다. 기본 기대값은 고정 원본 코드 또는 원본 엔진을 실행해 생성하며, AI가 원본을 읽고 작성한 기대값은 독립 원본 실행 증거가 아니다. 동일 입력·기대값을 Wasm과 DB 검증에 사용한다. 원본 실행 불가 시 이유를 기록하고 빌드는 계속하되 의미 검증은 미검증으로 보고한다. 고정 구현 재사용에도 이 보고 원칙을 적용한다.

`<skill>`은 이 SKILL.md의 디렉터리이며 명령은 그 위치의 실제 경로로 실행한다.

```bash
python3 <skill>/scripts/scaffold.py --name my_function --shape string-pair-i64 --compatibility <resolved-plan.json> --output <new-project>
```

현재 starter shape:

- `json-array-udaf`: TEXT 배열 입력과 TEXT 반환의 HANDLE UDAF 연결 코드 및 공통 조건 배열 파서. 계산·상태·직렬화·입력 정책·독립 기대값은 새 요청에 맞춰 구현한다. 조건 수·NULL·빈 입력 정책과 과거 참조/승인/검증 자료는 포함하지 않는다. 다른 반환 계약은 ABI와 함께 조정한다.

- `string-pair-i64`: UTF-8 문자열 둘 → i64. `src/logic.rs`에 `pub fn evaluate(left: &str, right: &str) -> i64`를 구현한다.
- `i64-unary`: i64 하나 → i64. `pub fn evaluate(value: i64) -> i64`를 구현한다. 오버플로 계약을 명시한다.
- `f64-scalar`: f64 인자 1~16개 → f64. `scaffold.py --shape f64-scalar --arguments s k t r sigma --name my_function --output <new-project>`처럼 원본 순서의 인자 이름을 지정한다. BASIC ABI와 SQL DOUBLE을 사용하며 실수 오차·Python 비교 설정은 [실수형 공용 프로필](references/python-porting.md#실수형-공용-프로필)을 따른다.

모든 scalar starter는 public SQL wrapper가 NULL을 먼저 전파한다. 반환·입력 타입이나 NULL 계약이 다른 요청을 이 형태로 억지 변환하지 않는다. 원본 함수의 옵션·집계·순서·상태 의미를 임의로 생략하거나 축소하지 않는다. [abi.md](references/abi.md)를 참고해 필요한 Rust 연결 코드, WIT, Cargo 설정, SQL 템플릿과 빌드·검증 경로를 확장한다. 기존 scripts의 shape/manifest/시그니처 검사도 확인하며 WIT나 템플릿만 바꾸고 호환된다고 가정하지 않는다. 숫자 및 명시적 TEXT 입력 HANDLE UDAF는 [공통 집계 프로필](references/common-pipeline.md)로 같은 build.py/db_verify.py를 사용한다. 다른 UDAF/TVF에는 필요한 프로필 확장을 구현한다. 새 형태는 테스트·컴파일하고 DB 검증 여부를 별도로 보고한다.

`src/logic.rs`와 의미 있는 Rust 테스트를 작성한다. `function.json`에 아래 형태의 독립 기대값을 채운다.

```json
{"id":"example", "args":["a","b"], "expected":1}
```

NULL은 JSON `null`, 반복 문자열은 `{"repeat":"a","count":4096}`로 표현한다. 오류 사례는 `expected` 대신 `expected_error`에 식별 가능한 메시지를 쓴다. 오류 sentinel이 필요하면 `error_sentinel`과 `error_message`를 설정한다. 정상 결과와 겹치는 sentinel을 사용하지 않는다.

문자열 길이를 제한한다면 `max_codepoints`를 설정해 wrapper가 Wasm 할당 전에 검사하게 하고 Rust에서도 방어한다. 기존 정수 반환 프로필의 출력 SQL은 BIGINT NULL이며 문자 인자는 utf8mb4를 명시한다. SQL 함수명은 Wasm export `evaluate`와 독립적이다.

선택적 고정 소스·계약·테스트는 기본 ZIP 밖의 개발 저장소 `development/library/`에 보관한다. 공통 실행기는 함수별 로직과 분리한다. 집계 함수의 의미와 상태 직렬화는 Rust에 구현하고, 콜백·독립 기대값·분산 검증 자료를 manifest에 선언한다. 함수별 Python 빌드/등록 실행기를 새로 복제하지 않는다.

## 반환 타입 계약

반환 타입을 생성하거나 변경할 때 [반환 계약과 검증](references/return-contracts.md)을 따른다. WIT는 SQL TEXT/LONGTEXT 길이 계층, charset, collation을 결정하지 않는다. manifest에 ABI와 SQL 계약을 분리하고 문자열은 사용자가 선택한 sql_type·charset·collation·nullable을 모두 명시한다. bare `returns: "string"`은 자동 변환하지 않고 확인한다. 구형 숫자·바이너리 계약은 문서화된 마이그레이션만 허용한다.

빌드 전 WIT·manifest 검사, 컴파일 후 실제 Wasm export 검사, SQL 생성 후 RETURNS·callback 검사를 각각 통과해야 한다. 서버 버전·UDF/UDAF/TVF·ABI별 미검증 프로필을 다른 프로필의 성공으로 대체하지 않는다. 정적 성공과 DB 등록·SHOW CREATE·호출·분산 callback·NULL/빈 입력 검증을 구분한다. 분산 호출 성공만으로 MERGE 또는 SERIALIZE/DESERIALIZE callback 경로를 직접 확인했다고 쓰지 않는다.

## 빌드와 산출물

[workflow.md](references/workflow.md)의 환경 설정 후:

```bash
python3 <skill>/scripts/build.py <new-project> --database t
```

Rust 1.85.0, wasm32-unknown-unknown을 고정한 프로필이다. 기존 정수·문자열 프로필은 외부 Rust 크레이트가 없다. Cargo.lock을 보존하고 `--locked --offline`로 테스트·빌드한다. 새 의존성이 필요하면 pin/lock하고 host import와 빌드 재현성을 검토한다. 현재 build.py는 import 없는 순수 함수 프로필만 받는다.

빌더는 `artifacts/`에 실제 Wasm, 도구로 생성한 Base64, 왕복 검증과 SHA-256, Wasm 구조 목록, 빌드 로그, 등록·호출 SQL을 남긴다. 새 형태의 빌드 경로에도 같은 검증·산출물 원칙을 적용한다. **성공적으로 컴파일한 실제 바이너리**를 인코딩하고 디코딩 결과가 원본과 같은지 검사한다. 가상 Base64나 placeholder SQL을 완료 산출물로 제공하지 않는다.

`python3 <skill>/scripts/status.py <new-project>`로 완료 상태를 판정하고, 전달용 ZIP은 `--bundle <output.zip>`으로 만든다. DB 성공이 필요한 경우 `--require-db`를 추가한다. 실패하거나 소스·도구·산출물 해시가 달라진 결과는 내보내지 않는다. [공통 실행 절차](references/common-pipeline.md)에 상태값과 공개 패키지 검증 명령이 있다.

사용자에게 아래 최종 결과 형식으로 `module.wasm`, `module.wasm.b64`, `register.sql`, `validate.sql`, `validate-errors.sql`의 클릭 가능한 파일 링크를 모두 제공한다. Base64 본문은 대화에 출력하지 않는다. DB 실행 전에는 등록용 산출물이 준비된 상태이며, 실제 엔진에서 로드·호출 가능한지는 미검증임을 명시한다. 구조 검사만으로 전체 Wasm validation 또는 SingleStore 호환성을 주장하지 않는다.

## DB 실행

DB 설정이 제공되고 그 DB 작업이 허용된 경우에만 실행한다. 사용자 제공 범위를 따른다. root는 필요 조건이 아니다. 설정은 Git 제외 로컬 INI 파일(mode 600), 비밀번호는 명령행·소스·로그에 넣지 않는다. [workflow.md](references/workflow.md)에 예시가 있다.

```bash
python3 <skill>/scripts/db_verify.py <new-project> --config <local-db.ini> --database t
```

함수명은 build.py 단계에서 고유하게 확정한다. DB runner는 `artifacts/` SQL 3개를 snapshot으로 그대로 복사해 실행하고 바이트와 SHA-256을 비교한다. 다른 이름이나 DB가 필요하면 해당 설정으로 재빌드한다.

실제 `@@memsql_version`, Wasm 변수, packet 크기와 기존 함수/프로시저/테이블/UDAF를 조회한 뒤 고유 `ssws_...` 이름으로 CREATE만 한다. 충돌 시 중단하고 새 이름을 쓴다. 기존 객체에 OR REPLACE/DROP을 적용하지 않는다. 전역 설정 변경·서버 재시작·다른 DB 변경은 포함하지 않는다. 기본은 생성 객체를 보존한다. `--cleanup`은 이번 프로세스가 생성한 객체만 정리한다.

`artifacts/runs/<name>/`의 실제 등록·검증·preflight SQL 및 문장 목록 snapshot과 JSON 보고서를 확인한다. 연결 실패 시 가능한 로컬 작업을 완료하되 DB 시도 실패와 DB 미실행을 구분한다. 실패는 단계/오류/원인/수정 내용을 비밀정보 없이 기록한다.

## 최종 결과 형식

함수 생성 요청의 최종 답변은 아래 순서로 간결하게 제공한다. 꺾쇠 안은 실제 소스·계약·`status.py` 결과로 채우며 성공을 가정하지 않는다. 일반 호출 SQL은 `validate.sql`로 안내하되, JSON 조건 배열 입력에서는 같은 공개 함수의 `JSON_BUILD_ARRAY` 호출 예시를 최종 답변에도 표시한다. 최종 결과 화면에는 성능 검증 항목을 표시하지 않는다.

```text
적용 가능성: <가능 / 조건부 가능 / 불가와 짧은 근거> — 대상 SingleStore <버전>
Wasm 생성: <성공 / 실패 / 미실행>
Base64 변환: <성공 / 실패 / 미실행>
DB 검증: <성공 / 실패 / 미실행 — 이유>

참조 출처와 원본 의미 검증:
- 공식 문서: <실제 참조 링크·버전; 미확보 시 이유>
- 원본 소스: <실제 참조 링크·고정 커밋/버전; 미확보 시 이유>
- 원본 실행: <엔진/소스 실행 방식·버전 또는 미실행 이유>
- 원본 의미 비교: <status.py의 semantic_verification 및 비교 범위; DB 검증과 별개>
- 비교 증거: <reference-verification.json 링크; 출처 링크 자체는 실행 증거가 아님>

등록 대상과 함수:
- DB: <대상 DB 이름; 미지정이면 미지정>
- 함수: <DB.함수명> — <UDF / 집계 함수(UDAF)> (<등록 완료 / 등록 예정 / 검증 후 정리>)
- 확인: <SHOW FUNCTIONS IN `DB`; 또는 SHOW AGGREGATES IN `DB`;>

반환 타입 계약:
- ABI 반환 타입: <string 등>
- SQL 반환 타입: <TEXT 등; core/public wrapper가 다르면 각각>
- 문자 집합: <utf8mb4 또는 해당 없음>
- Collation: <utf8mb4_bin 또는 해당 없음>
- NULL 정책: <NOT NULL / NULL; wrapper와 core 구분>
- WIT·SQL·Wasm 일치 여부: <정적 통과/실패/미검증>
- 실제 SingleStore 등록 검증: <통과/실패/미검증; 호출 검증 별도>

입력 계약과 제한:
- 인자: <순서대로 이름·SQL 타입·의미; 시간/금액 등 단위가 있으면 포함>
- NULL 처리: <입력 및 결과 정책>
- 지원 옵션: <옵션과 기본값; 없으면 없음>
- 선택한 지원 범위: <공개 함수 개수, SQL 인자 수, 지원 배열 길이 또는 고정 인자 범위>
- JSON 배열 호출 예시: <해당하는 경우 동일한 공개 함수에 JSON_BUILD_ARRAY로 2개·3개·5개 조건 전달>
- 빈 입력 정책: <실제 정책·원본 대비 차이·합의 근거>
- 원본 대비 차이: <공개 함수 수·호출 방식·반환 형식·계산 의미의 차이 또는 없음; 변경 합의 근거>
- 입력 크기 한도: <문자 수·행/상태 크기 등 실제 적용 한도>

실행 환경 제약 및 검증 상태:

| 항목 | 설정·정책 | 검증 상태 |
|---|---|---|
| 외부 기능 의존성 | <파일·네트워크·프로세스·스레드 생성 등 외부 기능 의존 여부> | <소스 검사 결과 · 생성 Wasm의 Import 검사 결과> |
| 함수 메모리 | <생성된 함수의 선형 메모리 한도> | <설정 확인 여부 · 실제 사용량 측정 여부> |
| 엔진 메모리 상한 | 기본값 약 4 GiB (대상 DB에서 확인한 설정이 있으면 해당 값 표시) | <함수 설정과 비교; 기본값 기준 판단과 실제 DB 검증 여부 구분> |
| ABI·타입 호환성 | <선택한 ABI 및 인터페이스 일치 조건> | <정적 검사 결과 · DB 호출 검증 결과> |
| 등록 SQL 크기 | <생성 SQL의 바이트 수 / DB의 max_allowed_packet> | <충족 / 미충족 / 미검증과 이유> |

산출물:
- module.wasm
- module.wasm.b64

직접 실행할 SQL:
1. register.sql — 함수 등록
2. validate.sql — 실제값·기대값·통과 여부 확인
3. validate-errors.sql — 명시된 오류 코드·메시지 확인
```

실제 답변에서는 위 파일명 5개를 사용자가 바로 열 수 있는 링크로 표시한다. 파일을 찾으라고만 안내하지 않는다. Base64 본문이나 긴 등록 SQL 전체를 결과창에 붙이지 않는다.

실행 환경 표는 실제 답변에서 Markdown 표로 렌더링하고, 다음 규칙을 따른다.

- 해당 실행의 실제 산출물·DB 조회·테스트 결과로 설정값과 상태를 채운다. 예제의 16 MiB나 Canonical ABI 등을 모든 함수에 고정하지 않는다. 확인할 수 없는 값은 추정하지 않고 미검증으로 표시한다.
- 검증 상태에는 `✅ 확인·통과`, `❌ 실패·미충족`, `➖ 미검증·미수행·해당 없음`을 사용하고 구체적인 이유를 함께 적는다. 일부만 확인했으면 같은 셀에 확인 범위와 미검증 범위를 각각 표시한다.
- DB에 접속하지 않았다면 DB 설정과 실제 호출 검증은 `➖ 미검증 — DB 미접속`으로 표시한다. 상단의 `DB 검증` 결과와 표의 DB 관련 상태를 일치시킨다. 등록 성공만으로 호출 검증을 통과 처리하지 않는다.
- 메모리 설정 확인과 실제 사용량 측정, 정적 ABI 검사와 DB 호출 검증을 각각 구분한다. 하나의 성공을 다른 검증의 성공으로 표시하지 않는다.
- 등록 SQL은 해당 실행에서 전달하는 파일의 실제 바이트 수를 기록한다. DB의 `max_allowed_packet`과 비교할 때는 실제 전송 단위도 확인하고, 파일 크기와 문장별 전송 크기가 다르면 그 근거를 보고서에 남긴다. DB 값이나 비교 근거가 없으면 충족으로 단정하지 않는다.
- 입력 범위·NULL·지원 옵션은 기존 `입력 계약과 제한`에서 설명하고 표에 중복하지 않는다.
- 상세 검사 근거는 생성 프로젝트의 `verification.md` 검증 보고서에 남기고 최종 답변에서 링크한다. 사용한 산출물·검사 결과·DB 조회값·측정 조건과 단위·미검증 이유를 기록하여 표의 각 상태를 추적할 수 있게 한다.

DB 설정과 권한이 있으면 Codex가 등록·호출을 수행한다. 접속할 수 없으면 이유와 미실행/실패를 구분하고 사용자가 SQL을 순서대로 실행하도록 안내한다. `validate.sql`은 모든 `passed=1`이 정상이며, `validate-errors.sql`은 각 주석의 코드와 메시지가 일치해야 정상이다. 오류 검증은 문장별 실행하거나 오류 후에도 계속 실행하는 클라이언트를 사용한다. 오류 사례가 없는 계약은 해당 파일 링크에 '해당 없음 — 정의된 오류 사례 없음'을 표시한다. 등록 SQL 재실행은 기존 이름과 충돌하므로 이미 등록된 경우 검증 SQL부터 실행하게 한다.

DB 검증 전에는 빌드 시 `artifacts/`의 SQL 3개와 등록 예정 이름을 제공한다. DB 등록을 수행했다면 `artifacts/runs/<name>/`의 SQL 3개를 한 묶음으로 제공하고 실제 등록 이름과 맞춘다. public wrapper/core 또는 nullable 집계 등 객체가 여러 개면 사용자 호출용 이름과 내부 보조 이름을 구분한다. 검증 후 정리했다면 등록 중인 것처럼 표현하지 않는다. 실패·부분·오래된 파일을 성공 산출물로 제공하지 않는다.

스킬 자체 평가에서는 새 디렉터리에서 재현하고 예제 재사용 검증과 독립 생성 검증을 구분한다.
